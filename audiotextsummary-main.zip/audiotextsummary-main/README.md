pip install virtualenv 


virtualenv env


env/scripts/activate


pip install -r requirements.txt	


python app.py

Enjoy
